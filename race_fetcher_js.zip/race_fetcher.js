// race_fetcher.js
// うまぴょんAI 出走馬取得処理
// 目的：文字化け対策 + 馬番を数字だけで安定取得する

const cheerio = require("cheerio");
const iconv = require("iconv-lite");

const USER_AGENT =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";

async function fetchHtml(url) {
  const res = await fetch(url, {
    method: "GET",
    headers: {
      "User-Agent": USER_AGENT,
      "Accept":
        "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "Accept-Language": "ja,en-US;q=0.9,en;q=0.8",
    },
  });

  if (!res.ok) {
    throw new Error(`HTML取得失敗: ${res.status} ${res.statusText}`);
  }

  const buffer = Buffer.from(await res.arrayBuffer());

  // netkeiba等の日本語ページ対策。まずEUC-JP、ダメならUTF-8。
  let html = iconv.decode(buffer, "EUC-JP");

  if (!html || html.includes("�") || html.includes("���")) {
    html = iconv.decode(buffer, "UTF-8");
  }

  return html;
}

function cleanText(value) {
  return String(value || "")
    .replace(/\u00a0/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeHorseNumber(value) {
  const text = cleanText(value);

  // 馬番は1〜18の数字のみ許可
  if (/^\d{1,2}$/.test(text)) {
    const n = Number(text);
    if (n >= 1 && n <= 18) return String(n);
  }

  return "";
}

function pickHorseName($, $row) {
  const selectors = [
    ".HorseName",
    ".Horse_Name",
    ".horse_name",
    "td.HorseInfo a",
    "td[class*='Horse'] a",
    "td[class*='horse'] a",
    "a[href*='/horse/']",
  ];

  for (const selector of selectors) {
    const text = cleanText($row.find(selector).first().text());
    if (text && !/^\d+$/.test(text)) return text;
  }

  const cells = [];
  $row.find("td").each((_, td) => {
    const text = cleanText($(td).text());
    if (text) cells.push(text);
  });

  for (const text of cells) {
    const candidate = cleanText(text.split(" ")[0]);
    if (
      candidate &&
      !/^\d{1,2}$/.test(candidate) &&
      !/^\d+\.\d+$/.test(candidate) &&
      !candidate.includes("牡") &&
      !candidate.includes("牝") &&
      !candidate.includes("セ") &&
      candidate.length >= 2
    ) {
      return candidate;
    }
  }

  return "";
}

function pickHorseNumber($, $row, horseName) {
  const directSelectors = [
    ".Umaban",
    ".HorseNum",
    ".HorseNumber",
    ".horse_number",
    "td[class*='Umaban']",
    "td[class*='umaban']",
    "td[class*='HorseNum']",
    "td[class*='horse_num']",
  ];

  for (const selector of directSelectors) {
    const n = normalizeHorseNumber($row.find(selector).first().text());
    if (n) return n;
  }

  // セルを左から見て、馬名より前にある数字を馬番候補にする
  const cells = [];
  $row.find("td").each((_, td) => {
    cells.push(cleanText($(td).text()));
  });

  const nameIndex = cells.findIndex((text) => horseName && text.includes(horseName));

  const searchEnd = nameIndex >= 0 ? nameIndex : Math.min(cells.length, 6);

  for (let i = 0; i < searchEnd; i++) {
    const n = normalizeHorseNumber(cells[i]);
    if (n) return n;
  }

  // 枠番と馬番が並ぶ形式では、先頭付近の数字のうち2つ目が馬番になりやすい
  const nums = [];
  for (let i = 0; i < Math.min(cells.length, 8); i++) {
    const n = normalizeHorseNumber(cells[i]);
    if (n) nums.push(n);
  }

  if (nums.length >= 2) return nums[1];
  if (nums.length === 1) return nums[0];

  return "";
}

function pickPopularity($, $row) {
  const selectors = [
    ".Popular",
    ".Popularity",
    "td[class*='Popular']",
    "td[class*='popularity']",
  ];

  for (const selector of selectors) {
    const text = cleanText($row.find(selector).first().text());
    const m = text.match(/\d+/);
    if (m) return m[0];
  }

  const text = cleanText($row.text());
  const m = text.match(/(\d+)人気/);
  return m ? m[1] : "";
}

function pickOdds($, $row) {
  const selectors = [
    ".Odds",
    ".odds",
    "td[class*='Odds']",
    "td[class*='odds']",
  ];

  for (const selector of selectors) {
    const text = cleanText($row.find(selector).first().text());
    const m = text.match(/\d+(?:\.\d+)?/);
    if (m) return m[0];
  }

  return "";
}

function parseHorsesFromHtml(html) {
  const $ = cheerio.load(html);
  const horses = [];
  const seen = new Set();

  const rowSelectors = [
    "tr.HorseList",
    "tr[class*='HorseList']",
    "tr[class*='horse']",
    "table tr",
  ];

  for (const rowSelector of rowSelectors) {
    $(rowSelector).each((_, row) => {
      const $row = $(row);
      const rowText = cleanText($row.text());

      if (!rowText) return;
      if (rowText.includes("馬名") && rowText.includes("騎手")) return;

      const horseName = pickHorseName($, $row);
      if (!horseName) return;

      const horseNumber = pickHorseNumber($, $row, horseName);

      // 馬名がURL由来で拾えている行だけ採用
      const hasHorseLink = $row.find("a[href*='/horse/']").length > 0;
      if (!hasHorseLink && horses.length > 0) return;

      const key = `${horseNumber || "no"}-${horseName}`;
      if (seen.has(key)) return;
      seen.add(key);

      horses.push({
        number: horseNumber,
        horseNumber,
        umaban: horseNumber,
        name: horseName,
        horseName,
        popularity: pickPopularity($, $row),
        odds: pickOdds($, $row),
      });
    });

    if (horses.length >= 5) break;
  }

  // 馬番が取れているものを優先して並べる
  horses.sort((a, b) => {
    const an = Number(a.number || 999);
    const bn = Number(b.number || 999);
    return an - bn;
  });

  return horses;
}

async function fetchRaceHorses(input) {
  const url =
    typeof input === "string"
      ? input
      : input?.url || input?.raceUrl || input?.entryUrl || input?.netkeibaUrl;

  if (!url) {
    throw new Error("race_fetcher.js: レースURLがありません");
  }

  const html = await fetchHtml(url);
  return parseHorsesFromHtml(html);
}

async function fetchRaceEntries(input) {
  return fetchRaceHorses(input);
}

async function getRaceHorses(input) {
  return fetchRaceHorses(input);
}

async function getRaceEntries(input) {
  return fetchRaceHorses(input);
}

async function fetchEntriesForRace(input) {
  return fetchRaceHorses(input);
}

module.exports = {
  fetchHtml,
  parseHorsesFromHtml,
  fetchRaceHorses,
  fetchRaceEntries,
  getRaceHorses,
  getRaceEntries,
  fetchEntriesForRace,
};
